/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.html", "./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        // Custom colors from Figma
        'yellow': {
          500: '#FDD80A',
        },
        'purple': {
          500: '#F02F8D',
        },
        'violet': {
          500: '#B700FF',
        },
        // Dark background colors
        'dark': {
          900: '#0D0D0D',
          800: '#1A1A1A',
          700: '#2D2D2D',
        }
      },
      fontFamily: {
        'sans': ['Proxima Nova', 'system-ui', 'sans-serif'],
        'heading': ['All Round Gothic', 'sans-serif'],
      },
      backgroundImage: {
        // Main gradient: yellow -> purple -> violet
        'gradient-main': 'linear-gradient(135deg, #FDD80A 0%, #F02F8D 50%, #B700FF 100%)',
        'gradient-main-horizontal': 'linear-gradient(90deg, #FDD80A 0%, #F02F8D 50%, #B700FF 100%)',
        'gradient-main-vertical': 'linear-gradient(180deg, #FDD80A 0%, #F02F8D 50%, #B700FF 100%)',
      },
      borderRadius: {
        '4xl': '2rem',
      }
    },
  },
  plugins: [],
}
